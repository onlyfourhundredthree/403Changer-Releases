//#region loader/shared.ts
var e = (e) => {
	let t = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(e.trim());
	return t ? [
		Number(t[1]),
		Number(t[2]),
		Number(t[3])
	] : null;
};
function t(t, n) {
	let r = e(t), i = e(n);
	if (!r || !i) return !1;
	for (let e = 0; e < 3; e++) if (r[e] !== i[e]) return i[e] > r[e];
	return !1;
}
//#endregion
//#region loader/index.ts
var n = "kyso1/ReimaginedLC", r = (e) => `https://cdn.jsdelivr.net/gh/${n}@cdn-v${e}/`, i = `https://api.github.com/repos/${n}/releases/latest`, a = {
	kty: "EC",
	crv: "P-256",
	x: "KSrJG2QZ1pt1duFZBR1w6eOdc_CaHxuPS5QtQ_EX5Ic",
	y: "1F9zXy1oSbqD4wm7rxQhMESD-H-HtNZTayJRsgSGXJY"
}, o = ["rcp-fe-lol-paw", "rcp-fe-lol-shared-components"], s = 216e5, c = (...e) => console.warn("[rlc-loader]", ...e), l = (e) => Array.from(new Uint8Array(e), (e) => e.toString(16).padStart(2, "0")).join(""), u = (e) => Uint8Array.from(atob(e.trim()), (e) => e.charCodeAt(0));
async function d(e, t = a) {
	let n = await crypto.subtle.importKey("jwk", t, {
		name: "ECDSA",
		namedCurve: "P-256"
	}, !1, ["verify"]);
	if (!await crypto.subtle.verify({
		name: "ECDSA",
		hash: "SHA-256"
	}, n, u(e.sig), e.manifest)) throw Error("assinatura inválida");
	let r = JSON.parse(new TextDecoder().decode(e.manifest));
	if (r.version !== e.version || typeof r.files?.["index.js"] != "string") throw Error(`manifest não é da versão ${e.version}`);
	if (l(await crypto.subtle.digest("SHA-256", e.code)) !== r.files["index.js"]) throw Error("index.js: sha256 não confere");
	return r;
}
async function f(e, t, n) {
	let i = async (n) => {
		let i = await t(r(e) + n);
		if (!i.ok) throw Error(`${n}: HTTP ${i.status}`);
		return i.arrayBuffer();
	}, [a, o, s] = await Promise.all([
		i("manifest.json"),
		i("manifest.sig"),
		i("index.js")
	]), c = {
		version: e,
		manifest: a,
		sig: new TextDecoder().decode(o),
		code: s
	};
	return await d(c, n), c;
}
function p(e) {
	let t = e?.rcp, n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = (e, t) => {
		try {
			e(t);
		} catch (e) {
			c(e);
		}
	};
	for (let e of o) try {
		t?.postInit?.(e, (t) => {
			n.set(e, t);
			for (let n of r.get(e) ?? []) i(n, t);
			r.delete(e);
		});
	} catch (e) {
		c(e);
	}
	return Object.assign(Object.create(e ?? null), { rcp: {
		preInit: (...e) => t?.preInit?.(...e),
		whenReady: (...e) => t?.whenReady?.(...e),
		postInit(e, a, ...s) {
			if (!o.includes(e)) return t?.postInit?.(e, a, ...s);
			n.has(e) ? i(a, n.get(e)) : r.set(e, [...r.get(e) ?? [], a]);
		}
	} });
}
async function m(e) {
	let n = "0.0.0";
	try {
		n = (await (await e.fetcher(`${e.base}app/manifest.json`)).json()).version;
	} catch {}
	try {
		let i = await e.cache.get();
		if (i && t(n, i.version)) {
			await d(i, e.key);
			let t = URL.createObjectURL(new Blob([i.code], { type: "text/javascript" }));
			return {
				version: i.version,
				base: r(i.version),
				url: t,
				revoke: () => URL.revokeObjectURL(t)
			};
		}
	} catch (e) {
		c("versão guardada inválida, usando a local", e);
	}
	return {
		version: n,
		base: `${e.base}app/`,
		url: `${e.base}app/index.js`
	};
}
async function h(e, n) {
	let r = await n.fetcher(i), a = r.ok ? (await r.json()).tag_name : null;
	if (typeof a != "string") return null;
	let o = a.trim().replace(/^v/, "");
	return !t(e.version, o) || o === e.ready ? null : (await n.cache.set(await f(o, n.fetcher, n.key)), e.ready = o, o);
}
var g = () => new Promise((e, t) => {
	let n = indexedDB.open("rlc-loader", 1);
	n.onupgradeneeded = () => n.result.createObjectStore("kv"), n.onsuccess = () => e(n.result), n.onerror = () => t(n.error);
}), _ = async (e, t) => {
	let n = await g();
	return new Promise((r, i) => {
		let a = t(n.transaction("kv", e).objectStore("kv"));
		a.onsuccess = () => r(a.result), a.onerror = () => i(a.error);
	}).finally(() => n.close());
}, v = {
	get: () => _("readonly", (e) => e.get("app")).then((e) => e ?? null),
	set: (e) => _("readwrite", (t) => t.put(e, "app")).then(() => void 0)
}, y = "rlc-loader.app", b = (e) => {
	let t = new Uint8Array(e), n = "";
	for (let e = 0; e < t.length; e += 32768) n += String.fromCharCode(...t.subarray(e, e + 32768));
	return btoa(n);
}, x = (e) => u(e).buffer;
function S(e, t) {
	return {
		async get() {
			try {
				let t = e?.has(y) ? e.get(y) : null;
				if (t && typeof t.version == "string" && typeof t.manifest == "string" && typeof t.sig == "string" && typeof t.code == "string") return {
					version: t.version,
					manifest: x(t.manifest),
					sig: t.sig,
					code: x(t.code)
				};
			} catch (e) {
				c("cópia do DataStore ilegível", e);
			}
			return t.get().catch(() => null);
		},
		async set(n) {
			try {
				e?.set(y, {
					version: n.version,
					manifest: b(n.manifest),
					sig: n.sig,
					code: b(n.code)
				});
			} catch (e) {
				c("DataStore não guardou", e);
			}
			await t.set(n).catch(() => {});
		}
	};
}
var C = Promise.resolve(null);
function w(e, t, n = window) {
	let r = p(e);
	return C = m(t).then(async ({ version: e, base: i, url: a, revoke: o }) => {
		let l = {
			version: e,
			base: i,
			ready: null
		};
		n.__rlcLoader = l;
		let u = await t.importer(a).finally(() => o?.());
		await u.init?.(r);
		let d = () => h(l, t).then((e) => e && n.dispatchEvent(new CustomEvent("rlc:update-ready", { detail: { version: e } }))).catch((e) => c("checagem de versão falhou", e));
		return d(), setInterval(d, s), u;
	}).catch((e) => (c("bundle não carregou", e), null)), C;
}
function T(e) {
	w(e, {
		fetcher: (e) => fetch(e),
		importer: (e) => import(
			/* @vite-ignore */
			e
),
		cache: S(globalThis.DataStore, v),
		base: new URL(
			/* @vite-ignore */
			".",
			import.meta.url
		).href
	});
}
async function E() {
	try {
		await (await C)?.load?.();
	} catch (e) {
		c(e);
	}
}
//#endregion
export { o as EARLY_APIS, i as LATEST_API, a as PUBLIC_KEY, n as REPO, w as boot, r as cdnBase, h as checkLatest, f as download, T as init, E as load, S as persistentCache, m as pickApp, p as proxyContext, d as verify };
